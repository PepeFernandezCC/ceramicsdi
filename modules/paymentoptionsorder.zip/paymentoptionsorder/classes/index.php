<?php
/**
 * Prevent directory listing.
 */
