<?php
/**
 * CERAMIC CONNECTION - Payment options order
 *
 * Model layer: knows the catalogue of payment option keys, and reads/writes
 * the saved order to/from Configuration. Kept free of any HTML/Smarty so it
 * can also be reused from the frontend override
 * (override/classes/checkout/PaymentOptionsFinder.php) if desired.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class PaymentOptionsOrderModel
{
    const CONFIG_KEY = 'PAYMENT_OPTIONS_ORDER';

    /**
     * Known payment option keys, matched by PaymentOptionsFinder against
     * either $option['module_name'] (for modules that expose a stable
     * technical name, e.g. ps_checkout) or "<hookKey>:<positionInGroup>"
     * (for modules that only expose a translated label, e.g. revolutpayment).
     *
     * Key => human label shown in the backoffice. This is also the default
     * order used on install and whenever a key has no saved position.
     *
     * @return array<string, string>
     */
    public static function getKnownOptions()
    {
        return [
            'revolutpayment:0' => 'Revolut - Pagar con tarjeta',
            'ps_checkout-paypal' => 'PayPal',
            'ps_checkout-paylater' => 'PayPal Pay Later',
            'revolutpayment:1' => 'Revolut Pay',
            'ps_checkout-google_pay' => 'Google Pay',
            'redsys:0' => 'Bizum',
            'ps_wirepayment:0' => 'Transferencia bancaria',
        ];
    }

    /**
     * Returns the saved order as a flat array of keys, guaranteed to contain
     * every key from getKnownOptions() exactly once (missing keys are
     * appended in their default order, unknown/removed keys are dropped).
     *
     * @return string[]
     */
    public static function getSavedOrder()
    {
        $known = array_keys(self::getKnownOptions());
        $saved = json_decode((string) Configuration::get(self::CONFIG_KEY), true);

        if (!is_array($saved)) {
            return $known;
        }

        $saved = array_values(array_intersect($saved, $known));
        $missing = array_diff($known, $saved);

        return array_merge($saved, $missing);
    }

    /**
     * @param string[] $submittedKeys Keys in the order submitted by the form
     *
     * @return bool
     */
    public static function saveOrder(array $submittedKeys)
    {
        $known = array_keys(self::getKnownOptions());
        $orderedKeys = array_values(array_intersect($submittedKeys, $known));
        $missing = array_diff($known, $orderedKeys);
        $finalOrder = array_merge($orderedKeys, $missing);

        return Configuration::updateValue(self::CONFIG_KEY, json_encode($finalOrder));
    }

    /**
     * Saved order, resolved to [key, label] pairs, ready for display.
     *
     * @return array<int, array{key: string, label: string}>
     */
    public static function getOrderedItemsForDisplay()
    {
        $labels = self::getKnownOptions();
        $items = [];

        foreach (self::getSavedOrder() as $key) {
            $items[] = [
                'key' => $key,
                'label' => isset($labels[$key]) ? $labels[$key] : $key,
            ];
        }

        return $items;
    }
}
