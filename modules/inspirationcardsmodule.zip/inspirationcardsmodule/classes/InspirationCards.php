<?php

class InspirationCards extends ObjectModel
{
    public $id_inspiration;
    public $active;
    public $date_add;
    public $date_upd;

    // multilang
    public $name;

    public static $definition = [
        'table' => 'inspirationcards',
        'primary' => 'id_inspiration',
        'multilang' => true,

        'fields' => [
            'active' => ['type' => self::TYPE_BOOL],
            'date_add' => ['type' => self::TYPE_DATE],
            'date_upd' => ['type' => self::TYPE_DATE],

            // lang
            'name' => [
                'type' => self::TYPE_STRING,
                'lang' => true,
                'required' => true,
                'size' => 255
            ],
        ],
    ];
}