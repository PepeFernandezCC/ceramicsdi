<?php

class AdminInspirationCardsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->table = 'inspirationcards';
        $this->identifier = 'id_inspiration';
        $this->className = 'InspirationCards';
        $this->bootstrap = true;
        $this->lang = true;

        parent::__construct();
    }

    public function renderList()
    {
        $this->fields_list = [
            'id_inspiration' => ['title' => 'ID'],
            'name' => ['title' => 'Nombre'],
        ];

        $this->_join = 'LEFT JOIN '._DB_PREFIX_.'inspirationcards_lang il 
            ON (a.id_inspiration = il.id_inspiration AND il.id_lang='.(int)$this->context->language->id.')';
        $this->_select = 'il.name';

        return parent::renderList();
    }

    public function renderForm()
    {
        $this->fields_form = [
            'form' => [
                'legend' => [
                    'title' => 'Inspiración',
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => 'Nombre',
                        'name' => 'name',
                        'required' => true,
                        'lang' => true,
                    ],
                    [
                        'type' => 'checkbox',
                        'label' => 'Espacio',
                        'name' => 'espacio',
                        'values' => [
                            'query' => [
                                ['id' => 13, 'name' => 'Baño'],
                                ['id' => 12, 'name' => 'Cocina'],
                                ['id' => 14, 'name' => 'Salón'],
                                ['id' => 15, 'name' => 'Dormitorio'],
                                ['id' => 16, 'name' => 'Exterior'],
                                ['id' => 37, 'name' => 'Piscina'],
                            ],
                            'id' => 'id',
                            'name' => 'name',
                        ],
                    ],
                    [
                        'type' => 'checkbox',
                        'label' => 'Uso',
                        'name' => 'uso',
                        'values' => [
                            'query' => [
                                ['id' => 1770, 'name' => 'Suelo'],
                                ['id' => 1771, 'name' => 'Pared'],
                                ['id' => 9999, 'name' => 'Moodboards'],
                            ],
                            'id' => 'id',
                            'name' => 'name',
                        ],
                    ],
                ],
                'submit' => [
                    'title' => 'Guardar',
                ],
            ],
        ];

        return parent::renderForm();
    }

    public function getFieldsValue($obj)
    {
        $fields = parent::getFieldsValue($obj);

        if (!Validate::isLoadedObject($obj)) {
            return $fields;
        }

        $categories = Db::getInstance()->executeS('
            SELECT id_category
            FROM '._DB_PREFIX_.'inspirationcards_category
            WHERE id_inspiration = '.(int) $obj->id
        );

        foreach ($categories as $cat) {
            $fields['espacio_'.$cat['id_category']] = 1;
            $fields['uso_'.$cat['id_category']] = 1;
        }

        return $fields;
    }

    public function processSave()
    {
        parent::processSave();

        $id = (int) $this->object->id;

        Db::getInstance()->delete('inspirationcards_category', 'id_inspiration = '.$id);

        $espacios = [13, 12, 14, 15, 16, 37];

        foreach ($espacios as $cat) {
            if (Tools::getValue('espacio_'.$cat)) {
                Db::getInstance()->insert('inspirationcards_category', [
                    'id_inspiration' => $id,
                    'id_category' => $cat,
                ]);
            }
        }

        $usos = [1770, 1771, 9999];

        foreach ($usos as $cat) {
            if (Tools::getValue('uso_'.$cat)) {
                Db::getInstance()->insert('inspirationcards_category', [
                    'id_inspiration' => $id,
                    'id_category' => $cat,
                ]);
            }
        }
    }
}