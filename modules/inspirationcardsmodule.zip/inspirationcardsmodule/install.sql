
CREATE TABLE IF NOT EXISTS `ps_inspirationcards` (
  id_inspiration INT AUTO_INCREMENT PRIMARY KEY,
  active TINYINT(1) DEFAULT 1,
  date_add DATETIME,
  date_upd DATETIME
);

CREATE TABLE IF NOT EXISTS `ps_inspirationcards_lang` (
  id_inspiration INT,
  id_lang INT,
  name VARCHAR(255),
  PRIMARY KEY(id_inspiration, id_lang)
);

CREATE TABLE IF NOT EXISTS `ps_inspirationcards_category` (
  id_inspiration INT,
  id_category INT,
  PRIMARY KEY(id_inspiration, id_category)
);

CREATE TABLE IF NOT EXISTS `ps_inspirationcards_feature` (
  id_inspiration INT,
  id_feature_value INT,
  PRIMARY KEY(id_inspiration, id_feature_value)
);
