<?php
if (!defined('_PS_VERSION_')) { exit; }

require_once dirname(__FILE__).'/classes/InspirationCards.php';

class InspirationCardsModule extends Module
{
    public function __construct()
    {
        $this->name = 'inspirationcardsmodule';
        $this->version = '1.2.0';
        $this->author = 'CERAMIC CONNECTION';
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = 'Inspiration Cards Module';
        $this->description = 'Gestión de Fichas de inspiraciones';
    }

    public function install()
    {
        return parent::install() && $this->runSql();
    }

    private function runSql()
    {
        $sql = Tools::file_get_contents(dirname(__FILE__).'/install.sql');
        $queries = preg_split("/;\s*\n/", $sql);

        foreach ($queries as $query) {
            if (!empty($query)) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }
        return true;
    }

    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminInspirationCards'));
    }
}
