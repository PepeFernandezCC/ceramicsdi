<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    Revolut
 * @copyright Since 2020 Revolut
 * @license   https://opensource.org/licenses/AFL-3.0  Academic Free License (AFL 3.0)
 */
global $_MODULE;
$_MODULE = [];
$_MODULE['<{revolutpayment}prestashop>revolutpayment_90d352192729e45ed7f08d1fa2f2a21c'] = 'Payer par carte (via Revolut)';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_033d39cedaa14fc8b162becc928573e5'] = 'Payer par carte de crédit ou débit';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_5bcb9d1a5898c2412882e5bb112bc80e'] = 'Le titre est un champ requis';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_c888438d14855d7d96a2724ee9c306bd'] = 'Les paramètres ont été enregistré';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_9b9cf9f8778f69b4c6cf37e66f886be8'] = 'Choisissez un status';
$_MODULE['<{revolutpayment}prestashop>my_account_84b26beee4823ee92afd73bd1928bca7'] = 'Vos cartes';
$_MODULE['<{revolutpayment}prestashop>configuration_3582b681fd2bedd6b481d10fc9889212'] = 'Bienvenue dans le plugin Revolut Gateway for Prestashop!';
$_MODULE['<{revolutpayment}prestashop>configuration_72f9206860da66e5f15507e6cde2dd43'] = 'Pour commencer à accepter les paiements de vos clients à des tarifs avantageux, vous devez suivre trois étapes simples:';
$_MODULE['<{revolutpayment}prestashop>configuration_de625ab220639be482353ecbbdcf51fb'] = 'Inscrivez-vous à Revolut Business';
$_MODULE['<{revolutpayment}prestashop>configuration_85036d78292813df664c916c4c464d5c'] = 'si vous n\'avez pas encore de compte';
$_MODULE['<{revolutpayment}prestashop>configuration_5c97f300f261d2d08e8ad73547faea99'] = 'Une fois votre compte Revolut Business approuvé';
$_MODULE['<{revolutpayment}prestashop>configuration_fb8e782ac47f2bee066a75909f4c3564'] = 'demandez un compte Commerçant';
$_MODULE['<{revolutpayment}prestashop>configuration_c5f787c028a8f0053cb4c90ab6b12870'] = 'Obtenez votre clé API de production';
$_MODULE['<{revolutpayment}prestashop>configuration_813266a8bb403b60f74af995e84923d1'] = 'et collez-la dans le champ correspondant ci-dessous';
$_MODULE['<{revolutpayment}prestashop>configuration_093ef2eaceae626b1d4dcb1a11bd70a2'] = 'Découvrez';
$_MODULE['<{revolutpayment}prestashop>configuration_c2ac80c7289931475a79c52d3c4a5c73'] = 'pourquoi accepter des paiements via Revolut est la bonne décision pour votre entreprise';
$_MODULE['<{revolutpayment}prestashop>configuration_70c361e1aaf016f0fce6d6daff219f73'] = 'Si vous souhaitez en savoir plus sur la configuration de ce plugin';
$_MODULE['<{revolutpayment}prestashop>configuration_ce07861a65a0b90eaab3b5bf064ed128'] = 'consultez notre documentation';
$_MODULE['<{revolutpayment}prestashop>configuration_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{revolutpayment}prestashop>configuration_170c6b09bf1f3b9df5cf4db0f5250b53'] = 'Activer le plugin';
$_MODULE['<{revolutpayment}prestashop>configuration_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{revolutpayment}prestashop>configuration_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{revolutpayment}prestashop>configuration_5404751dbc4e0393dd425b3c8c891064'] = 'Cette option contrôle l\'activation de la passerelle de paiement Revolut dans Prestashop';
$_MODULE['<{revolutpayment}prestashop>configuration_b78a3223503896721cca1303f776159b'] = 'Titre';
$_MODULE['<{revolutpayment}prestashop>configuration_d534f73a10ad1b0882a90698f719b41d'] = 'Titre affiché a l\'utilisateur lors de la sélection des méthodes de paiement';
$_MODULE['<{revolutpayment}prestashop>configuration_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Description';
$_MODULE['<{revolutpayment}prestashop>configuration_d3e3cf6d33a674b41429bb8cccf35b9a'] = 'Description de la méthode de paiement affiché durant le processus de paiement';
$_MODULE['<{revolutpayment}prestashop>configuration_650be61892bf690026089544abbd9d26'] = 'Mode';
$_MODULE['<{revolutpayment}prestashop>configuration_2652eec977dcb2a5aea85f5bec235b05'] = 'Bac à sable';
$_MODULE['<{revolutpayment}prestashop>configuration_955ad3298db330b5ee880c2c9e6f23a0'] = 'Production';
$_MODULE['<{revolutpayment}prestashop>configuration_d8f5f7dfe2e88694f1a6ae5618803d9e'] = 'Utiliser le mode test afin de valider votre intégration. Vous trouverez plus de détails à ce sujet';
$_MODULE['<{revolutpayment}prestashop>configuration_6c92285fa6d3e827b198d120ea3ac674'] = 'ici';
$_MODULE['<{revolutpayment}prestashop>configuration_91cd480d379382b417d225db2e91e4bb'] = 'Clef secrète (bac à sable)';
$_MODULE['<{revolutpayment}prestashop>configuration_3c841f349595d1169ea966e36615c228'] = 'La clef de l\'API \"Marchant\" tel que disponible dans les paramètres de votre portail Revolut Business ';
$_MODULE['<{revolutpayment}prestashop>configuration_997232eac860c6a1d135dd40ef04e87f'] = 'Clé secrète (Production)';
$_MODULE['<{revolutpayment}prestashop>configuration_9c5a332f7e48938ab06e90aa34064c15'] = 'Activer le mode \"Autorisation seulement\". Lorsque ce mode est activé, le paiement doit être capturé dans les 7 jours suivant l\'autorisation. Il est d\'usage de capturer le paiement lorsque la commande est sur le point d\'etre compléter. Si cette option est désactivée, les paiements sont capturés automatiquement au moment de l\'autorisation. En cas de doute, laissez cette option désactivée.';
$_MODULE['<{revolutpayment}prestashop>configuration_a9acd05ebb229589e7b9addca5331e14'] = 'Configurer les webhooks (production)';
$_MODULE['<{revolutpayment}prestashop>configuration_526d688f37a86d3c3f27d0c5016eb71d'] = 'Réinitialiser';
$_MODULE['<{revolutpayment}prestashop>configuration_ad2376beebecdcf7846ba973fa1a005b'] = 'Configurer';
$_MODULE['<{revolutpayment}prestashop>configuration_505a83f220c02df2f85c3810cd9ceb38'] = 'Configuration réussie';
$_MODULE['<{revolutpayment}prestashop>configuration_940e3681e11522e85bd49b768aefa009'] = 'Les webhooks ont été configurés';
$_MODULE['<{revolutpayment}prestashop>configuration_23827da0f4e1e4f10bb6b462b4c78bba'] = 'Échec de la configuration. Veuillez vérifier votre clef secrète et réessayer.';
$_MODULE['<{revolutpayment}prestashop>configuration_51417a34e2986d523a3a6b384fe5191b'] = 'Configurer les webooks pour synchroniser l\'achèvement des commandes Presatashop et Revolut.';
$_MODULE['<{revolutpayment}prestashop>configuration_d98fa77edc0fbe358ba2ec1750d53796'] = 'Configurer les webhooks (bac-à-sable)';
$_MODULE['<{revolutpayment}prestashop>configuration_b518f13f9922c8725d48019883dc24e0'] = 'Échec de la réinitialiser des webhooks';
$_MODULE['<{revolutpayment}prestashop>configuration_edd89eedfafea50bf9a8d92cee8a83c6'] = 'Statut assigné aux commandes Prestashop lorsque le paiement est terminé';
$_MODULE['<{revolutpayment}prestashop>configuration_c6a9094c053f62817cf82c904082378e'] = 'Statut par défaut: Expédié';
$_MODULE['<{revolutpayment}prestashop>configuration_b306bd38491a0dc8b45670cf13b8ad7b'] = 'Ce status sera automatiquement assigné aux commandes Prestashop lorsqu\'un paiement aura été complété depuis Révolut (par exemple en capturant le paiement). Pour fonctionner les web Hooks doivent être configurés.';
$_MODULE['<{revolutpayment}prestashop>configuration_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_a5a9c48781e917e107f52a1263d49e3d'] = 'Votre commande est en cours de traitement';
$_MODULE['<{revolutpayment}prestashop>configuration_fe4c6a5e7bd6793b37370e4e46daf998'] = 'Configuration avancé';
$_MODULE['<{revolutpayment}prestashop>configuration_18eaca809be3d20e366fbdf5c0d7be8d'] = 'Configurer les status des commandes';
$_MODULE['<{revolutpayment}prestashop>configuration_23bdb52938b99ec99237db5e6a16a2fc'] = 'Vous pouvez configurer les status des commandes pour chaccune des action qui peuvent efectuées avec cette extension';
$_MODULE['<{revolutpayment}prestashop>configuration_262862303a633ab571bb9da6119f4382'] = 'Cette option vous permet de déclencher automatiquement une action sur le paiement lors du changement de statut d\'une commande dans Prestashop';
$_MODULE['<{revolutpayment}prestashop>configuration_7e11268ceaff95fd41b775e87538e6c0'] = 'Par exemple, vous pouvez configurer qu\'un remboursement soit automatiquement émis depuis votre compte Revolut lorsque vous assignez à une commande Prestashop le status de \"Remboursé\'';
$_MODULE['<{revolutpayment}prestashop>configuration_b9fcb1ceec6f2635371c83204dbfdc77'] = 'Statut déclenchant un remboursement';
$_MODULE['<{revolutpayment}prestashop>configuration_0f9907c62d585faaab3efaf95a3406ac'] = 'Statut par défaut: Remboursé';
$_MODULE['<{revolutpayment}prestashop>configuration_8c07b2eccd6de02ec1b2397a3500506e'] = 'Statuts déclenchant un une capture du paiement';
$_MODULE['<{revolutpayment}prestashop>card_e2a39ecca8898a1ecd4bd3f9ee28b566'] = 'Vos cartes';
$_MODULE['<{revolutpayment}prestashop>card_8f483c2f32e7e5eb21ab63f5d365b87d'] = 'Voici les cartes que vous avez enregistrées avec le mode de paiement Revolut.';
$_MODULE['<{revolutpayment}prestashop>card_931d3a3ad177dd96a28c9642fec11b01'] = 'Numéro de carte';
$_MODULE['<{revolutpayment}prestashop>card_5b9d30924cc607010c513fb8374ae92b'] = 'Expire le mois';
$_MODULE['<{revolutpayment}prestashop>card_2534e702959e96d314b6618e2ad93cde'] = 'Expire l\'année';
$_MODULE['<{revolutpayment}prestashop>validation_e2b7dec8fa4b498156dfee6e4c84b156'] = 'Ce mode de paiement n\'est pas disponible';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_8413308502e55d970fb1ee095133d35e'] = 'Obtenir du cashback';
