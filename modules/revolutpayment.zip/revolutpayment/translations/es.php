<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    Revolut
 * @copyright Since 2020 Revolut
 * @license   https://opensource.org/licenses/AFL-3.0  Academic Free License (AFL 3.0)
 */
global $_MODULE;
$_MODULE = [];
$_MODULE['<{revolutpayment}prestashop>revolutpayment_90d352192729e45ed7f08d1fa2f2a21c'] = 'Pago con tarjeta (via Revolut)';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_033d39cedaa14fc8b162becc928573e5'] = 'Paga con tu tarjeta de crédito o débito';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_9b9cf9f8778f69b4c6cf37e66f886be8'] = 'Escoge estado';
$_MODULE['<{revolutpayment}prestashop>card_e2a39ecca8898a1ecd4bd3f9ee28b566'] = 'Sus tarjetas';
$_MODULE['<{revolutpayment}prestashop>validation_e2b7dec8fa4b498156dfee6e4c84b156'] = 'El método de pago no está disponible';
$_MODULE['<{revolutpayment}prestashop>configuration_3582b681fd2bedd6b481d10fc9889212'] = '¡Bienvenido al plugin Revolut Gateway for Prestashop!';
$_MODULE['<{revolutpayment}prestashop>configuration_72f9206860da66e5f15507e6cde2dd43'] = 'Para comenzar a aceptar pagos de sus clientes a excelentes precios, deberá seguir tres sencillos pasos:';
$_MODULE['<{revolutpayment}prestashop>configuration_de625ab220639be482353ecbbdcf51fb'] = 'Regístrese en Revolut Business';
$_MODULE['<{revolutpayment}prestashop>configuration_85036d78292813df664c916c4c464d5c'] = 'si aún no tiene una cuenta';
$_MODULE['<{revolutpayment}prestashop>configuration_5c97f300f261d2d08e8ad73547faea99'] = 'Una vez que se haya aprobado su cuenta Revolut Business';
$_MODULE['<{revolutpayment}prestashop>configuration_fb8e782ac47f2bee066a75909f4c3564'] = 'solicite una Cuenta de Comercio';
$_MODULE['<{revolutpayment}prestashop>configuration_c5f787c028a8f0053cb4c90ab6b12870'] = 'Obtenga su clave API de producción';
$_MODULE['<{revolutpayment}prestashop>configuration_813266a8bb403b60f74af995e84923d1'] = 'y péguela en el campo correspondiente a continuación';
$_MODULE['<{revolutpayment}prestashop>configuration_093ef2eaceae626b1d4dcb1a11bd70a2'] = 'Obtenga más información';
$_MODULE['<{revolutpayment}prestashop>configuration_c2ac80c7289931475a79c52d3c4a5c73'] = 'sobre por qué aceptar pagos a través de Revolut es la decisión correcta para su negocio';
$_MODULE['<{revolutpayment}prestashop>configuration_70c361e1aaf016f0fce6d6daff219f73'] = 'Si desea saber más sobre cómo configurar este complemento';
$_MODULE['<{revolutpayment}prestashop>configuration_ce07861a65a0b90eaab3b5bf064ed128'] = 'consulte nuestra documentación';
$_MODULE['<{revolutpayment}prestashop>configuration_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{revolutpayment}prestashop>configuration_170c6b09bf1f3b9df5cf4db0f5250b53'] = 'Activar plugin?';
$_MODULE['<{revolutpayment}prestashop>configuration_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{revolutpayment}prestashop>configuration_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{revolutpayment}prestashop>configuration_5404751dbc4e0393dd425b3c8c891064'] = 'Esto controla si la extensión está activa en Prestashop';
$_MODULE['<{revolutpayment}prestashop>configuration_b78a3223503896721cca1303f776159b'] = 'Título';
$_MODULE['<{revolutpayment}prestashop>configuration_d534f73a10ad1b0882a90698f719b41d'] = 'Controla el título de la extensión que se muestra cuando el usuario está realizando la compra.';
$_MODULE['<{revolutpayment}prestashop>configuration_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Descripción';
$_MODULE['<{revolutpayment}prestashop>configuration_d3e3cf6d33a674b41429bb8cccf35b9a'] = 'Controla la descripción de la pasarela de pago que se muestra cuando el usuario está realizando la compra.';
$_MODULE['<{revolutpayment}prestashop>configuration_650be61892bf690026089544abbd9d26'] = 'Modo';
$_MODULE['<{revolutpayment}prestashop>configuration_2652eec977dcb2a5aea85f5bec235b05'] = 'Sandbox';
$_MODULE['<{revolutpayment}prestashop>configuration_955ad3298db330b5ee880c2c9e6f23a0'] = 'Live';
$_MODULE['<{revolutpayment}prestashop>configuration_d8f5f7dfe2e88694f1a6ae5618803d9e'] = 'Selecciona el modo Sandbox para testar la integración. Puedes encontrar más información sobre cómo hacer esto';
$_MODULE['<{revolutpayment}prestashop>configuration_6c92285fa6d3e827b198d120ea3ac674'] = 'aquí';
$_MODULE['<{revolutpayment}prestashop>configuration_91cd480d379382b417d225db2e91e4bb'] = 'Clave API (Modo sandbox)';
$_MODULE['<{revolutpayment}prestashop>configuration_3c841f349595d1169ea966e36615c228'] = 'Clave API que se encuentra en la configuración de Comercio en su portal de Revolut.';
$_MODULE['<{revolutpayment}prestashop>configuration_997232eac860c6a1d135dd40ef04e87f'] = 'Clave API (Modo live)';
$_MODULE['<{revolutpayment}prestashop>configuration_9c5a332f7e48938ab06e90aa34064c15'] = 'Activa el modo “Solo autorización”. Esto permite que el pago sea capturado hasta 7 días después de que el usuario haga el pedido (por ejemplo, cuando el producto ha sido enviado o recibido). Si esta opción no está marcada, Revolut intentará autorizar y capturar todos los pagos.';
$_MODULE['<{revolutpayment}prestashop>configuration_a9acd05ebb229589e7b9addca5331e14'] = 'Configurar webhook (Modo live)';
$_MODULE['<{revolutpayment}prestashop>configuration_526d688f37a86d3c3f27d0c5016eb71d'] = 'Reconfigurar';
$_MODULE['<{revolutpayment}prestashop>configuration_ad2376beebecdcf7846ba973fa1a005b'] = 'Configurar';
$_MODULE['<{revolutpayment}prestashop>configuration_505a83f220c02df2f85c3810cd9ceb38'] = 'Hecho!';
$_MODULE['<{revolutpayment}prestashop>configuration_940e3681e11522e85bd49b768aefa009'] = 'El webhook ha sido configurado';
$_MODULE['<{revolutpayment}prestashop>configuration_23827da0f4e1e4f10bb6b462b4c78bba'] = 'No se puede configurar el webhook ahora mismo. Compruebe su clave API y vuélvalo a intentar.';
$_MODULE['<{revolutpayment}prestashop>configuration_51417a34e2986d523a3a6b384fe5191b'] = 'Configure un webhook para sincronizar los pedidos de Prestashop cuando se completa un pedido por el lado de Revolut';
$_MODULE['<{revolutpayment}prestashop>configuration_d98fa77edc0fbe358ba2ec1750d53796'] = 'Configurar webhook (Modo sandbox)';
$_MODULE['<{revolutpayment}prestashop>configuration_b518f13f9922c8725d48019883dc24e0'] = 'No se puede reconfigurar el webhook ahora mismo';
$_MODULE['<{revolutpayment}prestashop>configuration_edd89eedfafea50bf9a8d92cee8a83c6'] = 'Estado para pedidos completados';
$_MODULE['<{revolutpayment}prestashop>configuration_c6a9094c053f62817cf82c904082378e'] = 'Por defecto: Pago aceptado';
$_MODULE['<{revolutpayment}prestashop>configuration_b306bd38491a0dc8b45670cf13b8ad7b'] = 'Este estado se aplicará automáticamente a los pedidos que se hayan completado por el lado de Revolut. Esta información solo puede estar disponible si el Webhook se ha configurado correctamente.';
$_MODULE['<{revolutpayment}prestashop>configuration_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{revolutpayment}prestashop>configuration_fe4c6a5e7bd6793b37370e4e46daf998'] = 'Configuración avanzada';
$_MODULE['<{revolutpayment}prestashop>configuration_18eaca809be3d20e366fbdf5c0d7be8d'] = 'Configurar el estado de los pedidos';
$_MODULE['<{revolutpayment}prestashop>configuration_23bdb52938b99ec99237db5e6a16a2fc'] = 'Puede configurar el estado de los pedidos para cada una de las acciones que se pueden realizar con esta extensión.';
$_MODULE['<{revolutpayment}prestashop>configuration_262862303a633ab571bb9da6119f4382'] = 'Con esta opción activada, cambiar el estado de un pedido en Prestashop desencadenará un evento en su portal de Revolut.';
$_MODULE['<{revolutpayment}prestashop>configuration_7e11268ceaff95fd41b775e87538e6c0'] = 'Por ejemplo, por defecto si usted actualiza el estado de un pedido a “Reintegrado”, automáticamente se iniciará un reintegro para el pedido y la cantidad correspondientes.';
$_MODULE['<{revolutpayment}prestashop>configuration_b9fcb1ceec6f2635371c83204dbfdc77'] = 'Estado para iniciar el reintegro de un pedido en Revolut';
$_MODULE['<{revolutpayment}prestashop>configuration_0f9907c62d585faaab3efaf95a3406ac'] = 'Por defecto: Reintegrado';
$_MODULE['<{revolutpayment}prestashop>configuration_8c07b2eccd6de02ec1b2397a3500506e'] = 'Estado para iniciar la captura de un pedido en Revolut';
$_MODULE['<{revolutpayment}prestashop>card_8f483c2f32e7e5eb21ab63f5d365b87d'] = 'Aquí están las tarjetas que ha guardado con el método de pago Revolut.';
$_MODULE['<{revolutpayment}prestashop>card_931d3a3ad177dd96a28c9642fec11b01'] = 'Número de tarjeta';
$_MODULE['<{revolutpayment}prestashop>card_5b9d30924cc607010c513fb8374ae92b'] = 'Mes de vencimiento';
$_MODULE['<{revolutpayment}prestashop>card_2534e702959e96d314b6618e2ad93cde'] = 'Año de expiración';
$_MODULE['<{revolutpayment}prestashop>payment_f25c7a079dd156ff1395486b3ff788cc'] = 'Confirmar y pagar';
$_MODULE['<{revolutpayment}prestashop>payment_2d6a0b51ccd9584aae023f6f2f5bc4c4'] = 'El Carro de Compras está Vacío.';
$_MODULE['<{revolutpayment}prestashop>payment_08ec86d192e044cb37e12337e685df11'] = 'Ha elegido pagar con el pago Revolut.';
$_MODULE['<{revolutpayment}prestashop>payment_c46148980588559fa7ab953908e330f6'] = 'El monto total de su pedido:';
$_MODULE['<{revolutpayment}prestashop>payment_569fd05bdafa1712c4f6be5b153b8418'] = 'otros métodos de pago';
$_MODULE['<{revolutpayment}prestashop>payment_99938b17c91170dfb0c2f3f8bc9f2a85'] = 'Pagar';
$_MODULE['<{revolutpayment}prestashop>my_account_84b26beee4823ee92afd73bd1928bca7'] = 'Sus tarjetas';
$_MODULE['<{revolutpayment}prestashop>payment_eeceac1af4e7620894d6d2083921bb73'] = 'Compra ahora';
$_MODULE['<{revolutpayment}prestashop>payment_return_498cd895eb5a102c5aeb977e2b928dee'] = '¡Gracias!';
$_MODULE['<{revolutpayment}prestashop>payment_return_f7a4c4f007f6ab7b3c2d6f12650de2ca'] = 'Su pedido ha sido realizado y será procesado pronto.';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_8413308502e55d970fb1ee095133d35e'] = 'Obtener devolución de efectivo';
$_MODULE['<{revolutpayment}prestashop>revolutpayment_a5a9c48781e917e107f52a1263d49e3d'] = 'Su pedido se está procesando';
